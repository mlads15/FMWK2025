<html>
    <head>
        <title>Cadastro de cidade</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_nomeCidade'>nomeCidade</label>
<input type='text' name='campo_nomeCidade'><br>
<label for='campo_idEstado'>idEstado</label>
<input type='text' name='campo_idEstado'><br>
<label for='campo_habitantes'>habitantes</label>
<input type='text' name='campo_habitantes'><br>

        </form>
    </body>
</html>