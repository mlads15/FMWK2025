<html>
    <head>
        <title>Cadastro de livros</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_titulo'>titulo</label>
<input type='text' name='campo_titulo'><br>
<label for='campo_genero'>genero</label>
<input type='text' name='campo_genero'><br>
<label for='campo_qtd_paginas'>qtd_paginas</label>
<input type='text' name='campo_qtd_paginas'><br>
<label for='campo_autor'>autor</label>
<input type='text' name='campo_autor'><br>

        </form>
    </body>
</html>